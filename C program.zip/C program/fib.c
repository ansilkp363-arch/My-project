#include<stdio.h>

int fib(int);

void main(){
int n,i,f;
printf("enter the number of terms in fibonacci sers:");
scanf("%d",&n);
printf("fibunacci series:");
for(i=0;i<n;++i)
{
f=fib(i);
printf("%d",f);
}
}
int fib(int j)
{
int fi;
if(j==0)
{
return 0;
}
else if(j==1)
{
return (1);
}
else
{
fi=fib(j-1)+fib(j-2);
return (fi);
}
}