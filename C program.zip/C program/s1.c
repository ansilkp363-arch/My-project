#include<stdio.h>
int main()
{
	float a,b,x;
	int n;
	char ch;
	
	do{
    printf("\n=====simple calculator=====\n");
    
    
	printf("1.Adition\n");
	printf("2.substaction\n");
	printf("3.multiplication\n");
	printf("4.division\n");
	scanf("%d",&n);
	if(n>4){
	printf("Invalid entry!");
	return 0;
	}
else if(n==1){
	printf("enter 2 numbers");
     scanf("%f%f",&a,&b);
	x= a+b;
	printf("the answer is:%.2f",x);
	}
else if(n==2){
	printf("enter 2 numbers");
     scanf("%f%f",&a,&b);
	x= a-b;
	printf("the answer is:%.2f",x);
	}
	else if(n==3){
  printf("enter 2 numbers");
     scanf("%f%f",&a,&b);
	x= a*b;
	printf("the answer is:%.2f",x);
	}
	else if(n==4){
	printf("enter 2 numbers");
     scanf("%f%f",&a,&b);
	x= a/b;
	printf("the answer is:%.2f",x);
	}
   printf("\nDO YOU WANT TO CONTINIUE (Y/N) ?\n");
   scanf(" %c",&ch);
}
while(ch=='Y'||ch=='y');
printf("\nThank you for using calculator\n");
return 0;
	}

   