#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int main() {
    int choice;
    char hex[100];
    int decimal;

    while (1) {
        printf("\nHexadecimal Conversion Menu:\n");
        printf("1. Decimal to Hexadecimal\n");
        printf("2. Hexadecimal to Decimal\n");
        printf("3. Exit\n");
        printf("Enter choice: ");
        scanf("%d", &choice);

        if (choice == 1) {
            printf("Enter decimal number: ");
            scanf("%d", &decimal);
            printf("Hexadecimal: %X\n", decimal);
        } 
        else if (choice == 2) {
            printf("Enter hexadecimal number: ");
            scanf("%s", hex);
            decimal = (int)strtol(hex, NULL, 16);
            printf("Decimal: %d\n", decimal);
        } 
        else if (choice == 3) {
            break;
        } 
        else {
            printf("Invalid choice.\n");
        }
    }

    return 0;
}