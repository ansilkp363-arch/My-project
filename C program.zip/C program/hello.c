#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>

void caesar(char *text, int shift) {
    for (int i = 0; text[i] != '\0'; ++i) {
        char c = text[i];
        if (isupper((unsigned char)c)) {
            text[i] = (char)((((c - 'A') + shift) % 26 + 26) % 26 + 'A');
        } else if (islower((unsigned char)c)) {
            text[i] = (char)((((c - 'a') + shift) % 26 + 26) % 26 + 'a');
        } else {
            text[i] = c;
        }
    }
}

int main(void) {
    char input[1000];
    int key;
    char mode;
    char choice;

    do {
        printf("\nEnter text (max 999 chars):\n");
        if (!fgets(input, sizeof(input), stdin)) {
            fprintf(stderr, "Input error\n");
            return 1;
        }
        size_t len = strlen(input);
        if (len > 0 && input[len-1] == '\n') input[len-1] = '\0';

        printf("Enter key (shift amount, integer): ");
        if (scanf("%d", &key) != 1) {
            fprintf(stderr, "Invalid key\n");
            return 1;
        }

        int ch;
        while ((ch = getchar()) != '\n' && ch != EOF) {}

        printf("Encrypt or Decrypt? (E/D): ");
        if (scanf("%c", &mode) != 1) {
            fprintf(stderr, "Invalid choice\n");
            return 1;
        }
        while ((ch = getchar()) != '\n' && ch != EOF) {}

        if (mode == 'E' || mode == 'e') {
            caesar(input, key);
            printf("\nEncrypted text:\n%s\n", input);
        } else if (mode == 'D' || mode == 'd') {
            caesar(input, -key);
            printf("\nDecrypted text:\n%s\n", input);
        } else {
            printf("Unknown mode. Use 'E' to encrypt or 'D' to decrypt.\n");
        }

        printf("\nDo you want to process another text? (Y/N): ");
        if (scanf(" %c", &choice) != 1) break;

        while ((ch = getchar()) != '\n' && ch != EOF) {}

    } while (choice == 'Y' || choice == 'y');

    printf("Goodbye!\n");
    return 0;
}